import numpy as np

A = np.array([
      [1,2,3],
      [4,5,6],
      [7,8,9]
])
#print (A)
B = np.array([
      [1,2,3],
      [4,5,6],
      [7,8,9]
])
#print (B)

#penjumlahan A+B 
C = np.add(A,B)
print(C)

#perkalian A*B
D = np.dot(A,B)
print(D)
